/* 
 * File:   main.cpp
 * Author: Theopolis Armstrong
 * Created on February 12th, 2019, 3:09 PM
 * Purpose:  IntroLab "Hello World" program
 */

//System Libraries
#include <iostream>  //Input/Output Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    
    //Declare Variables
    
    //Initialize or input i.e. set variable values
    
    //Map inputs -> outputs
    
    //Display the outputs
    cout << "Hello, World!\n";
    
    //Exit stage right or left!
    return 0;
}